

<?php $__env->startSection('content'); ?>
<form action="/add/update/<?php echo e($mahasiswas->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
    <input type="text" name="nama" id="nama" value="<?php echo e($mahasiswas->nama); ?>">
    <input type="text" name="nim" id="nim" value="<?php echo e($mahasiswas->nim); ?>">
    <input type="text" name="alamat" id="alamat" value="<?php echo e($mahasiswas->alamat); ?>">
    <input type="text" name="fakultas" id="fakultas" value="<?php echo e($mahasiswas->fakultas); ?>">
    <br>
    <button type="submit" class="btn btn-primary mt-4">update</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Laravel-project\project_3\resources\views/add.blade.php ENDPATH**/ ?>