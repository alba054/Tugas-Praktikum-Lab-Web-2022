

<?php $__env->startSection('content'); ?>
<table class="table table-striped">
    <thead>
        <th>No.</th>
        <th>Nama</th>
        <th>NIM</th>
        <th>Alamat</th>
        <th>Fakultas</th>
        <th>Aksi</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($person->id); ?></td>
            <td><?php echo e($person->nama); ?></td>
            <td><?php echo e($person->nim); ?></td>
            <td><?php echo e($person->alamat); ?></td>
            <td><?php echo e($person->fakultas); ?></td>
            <td>
                <a href="/add/edit/<?php echo e($person->id); ?>" class="btn btn-success">Edit</a>
                <a href="/add/delete/<?php echo e($person->id); ?>" class="btn btn-danger">Delete</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($mahasiswa->links()); ?>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
    Add Data
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/" method="POST">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" id="nama">

                    <label for="nama">NIM</label>
                    <input type="text" class="form-control" name="nim" id="nim">

                    <label for="nama">Alamat</label>
                    <input type="text" class="form-control" name="alamat" id="alamat">

                    <label for="nama">Fakultas</label>
                    <input type="text" class="form-control" name="fakultas" id="fakultas">

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Laravel-project\project_3\resources\views/index.blade.php ENDPATH**/ ?>